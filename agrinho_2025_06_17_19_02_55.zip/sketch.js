let etapaAtual = 0;
let tempoUltimaTroca = 0;
let intervalo = 4000;

function setup() {
  createCanvas(800, 400);
  textAlign(CENTER, CENTER);
  textSize(22);
}

function draw() {
  background(240);

  // Desenha o texto
  fill(0);
  text(getTextoEtapa(etapaAtual), width / 2, 30);

  // Desenha a ilustração da etapa
  desenharEtapa(etapaAtual);

  // Avança a etapa a cada X segundos
  if (millis() - tempoUltimaTroca > intervalo) {
    etapaAtual++;
    tempoUltimaTroca = millis();
    if (etapaAtual > 6) etapaAtual = 0;
  }
}

function getTextoEtapa(etapa) {
  let textos = [
    "1. A semente é plantada.",
    "2. A planta cresce com sol e água.",
    "3. A colheita é feita pelos agricultores.",
    "4. Os alimentos são selecionados.",
    "5. Eles são embalados com cuidado.",
    "6. São transportados até os mercados.",
    "7. Você compra e leva para casa!"
  ];
  return textos[etapa];
}

function desenharEtapa(etapa) {
  switch (etapa) {
    case 0: // Semente
      fill(139, 69, 19);
      ellipse(width / 2, height / 2, 20, 30);
      break;

    case 1: // Planta
      fill(139, 69, 19);
      rect(width / 2 - 5, height / 2, 10, 40);
      fill(34, 139, 34);
      ellipse(width / 2, height / 2 - 10, 60, 60);
      break;

    case 2: // Colheita
      fill(255, 215, 0);
      ellipse(width / 2 - 40, height / 2, 30, 30);
      ellipse(width / 2, height / 2, 30, 30);
      ellipse(width / 2 + 40, height / 2, 30, 30);
      break;

    case 3: // Seleção
      fill(255, 215, 0);
      ellipse(width / 2, height / 2, 30, 30);
      stroke(0);
      noFill();
      rect(width / 2 - 20, height / 2 - 20, 40, 40);
      noStroke();
      break;

    case 4: // Embalagem
      fill(173, 216, 230);
      rect(width / 2 - 40, height / 2 - 30, 80, 60);
      break;

    case 5: // Transporte
      fill(100);
      rect(width / 2 - 60, height / 2 - 20, 120, 40);
      fill(0);
      ellipse(width / 2 - 40, height / 2 + 20, 20, 20);
      ellipse(width / 2 + 40, height / 2 + 20, 20, 20);
      break;

    case 6: // Mercado
      fill(255, 0, 0);
      rect(width / 2 - 60, height / 2 - 40, 120, 80);
      fill(255);
      text("Mercado", width / 2, height / 2);
      break;
  }
}
	
Pause